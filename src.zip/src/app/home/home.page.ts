import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  constructor(private loadingCtrl: LoadingController, private alertController: AlertController) {}

  async showLoading() {
    const loading = await this.loadingCtrl.create({
      message: 'Loading...',
      duration: 3000,
      cssClass: 'custom-loading',
    });

    loading.present();

    
  }
  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Alert!',
      subHeader: 'Important message',
      message: 'Character ID can not be changed unless you have premium account. If you force change name you will get banned.',
      buttons: ['Aight!'],
    });
    

    await alert.present()
  }
  

  info: any = {};

  saveData() { 
    console.log(this.info); 
    }
    

}







